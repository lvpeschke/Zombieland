COURSE	: INGI1131
PROJECT	: Zombieland
AUTHORS	: Peschke Lena and Sedda Mélanie
DATE	: May, 9th 2014

* CONTENT
Brave.oz
Cell.oz
Config.oz
Controller.oz
Game.oz
GUI.oz
Zombie.oz
map_test.ozp
Makefile
images/

* COMPILATION
Type these instructions in your terminal : 
	# cd <this_directory_path>
	# make

* EXECUTION
Type this instruction in your terminal :
	# ozengine Game.ozf ARGUMENTS

Allowed arguments are :
--map <file>.ozp	% map file
--zombie <number>	% initial number of zombies
--item <number>		% number items the Brave needs to collect
--bullet <number>	% initial number of bullets the Brave has

Enjoy the game!
